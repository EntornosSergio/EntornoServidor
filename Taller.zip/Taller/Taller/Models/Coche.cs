﻿namespace Taller.Models
{
    public class Coche
    {
        public string Modelo { get; set; }

        public string Matricula { get; set; }

        public string Marca { get; set; }

        public string Año { get; set; }

        public Dueño dueños { get; set; }
    }
}
