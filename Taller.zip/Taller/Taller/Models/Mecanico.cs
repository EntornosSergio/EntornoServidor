﻿namespace Taller.Models
{
    public class Mecanico
    {
        public DateTime Fecha_Alta { get; set; }
        public string Foto { get; set; }

    }
}
