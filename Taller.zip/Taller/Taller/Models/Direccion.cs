﻿namespace Taller.Models
{
    public class Direccion
    {
        public string Calle { get; set; }

        public int Numero { get; set; }

        public int Codigo_Postal { get; set; }

        public string Provincia { get; set; }
    }
}
