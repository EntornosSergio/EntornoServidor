﻿namespace Taller.Models
{
    public class Dueño
    {
        public Direccion direccion { get; set; }
    }
}
