from setuptools import setup

setup(
    name="mismates",
    version="1.0",
    description="Ejemplo distribuir paquetes",
    packages=["mismates"]
)