#import potencias
from operaciones import suma
from potencias import *
import os

x=3
y=8

#r=potencias.cubo(x)

su=suma(x,y)
r=cuadrado(y)

print(os.getcwd())