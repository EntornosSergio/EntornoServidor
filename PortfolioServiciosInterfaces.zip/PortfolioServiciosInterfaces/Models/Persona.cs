﻿namespace PortfolioServicios.Models
{
    public class Persona
    {
        public String Nombre { get; set; }
        public String Imagen { get; set; }
        public int Edad { get; set; }
    }
}
