﻿
namespace PortfolioServicios.Models
{
    public class HomeViewModel
    {
        public List<Proyecto> Proyectos { get; set; }
        public Persona P { get; set; }
    }
}
