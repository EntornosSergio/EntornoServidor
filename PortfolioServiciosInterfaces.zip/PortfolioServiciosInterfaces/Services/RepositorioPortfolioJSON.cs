﻿namespace PortfolioServicios.Services
{
    public class RepositorioPortfolioJSON
    {
    }
}
