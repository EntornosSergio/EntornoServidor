using Microsoft.AspNetCore.Mvc;
using Practica1.Models;
using System.Collections.Generic;
using Microsoft.Extensions.Logging;

namespace Practica1.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            Portfolio p = new Portfolio()
            {
                Persona = new Persona()
                {
                    Nombre = "SergisDAW",
                    Edad = 23,
                    Perfil="Full-stack"
                },
                Proyectos = new ListaProyectos
                {
                    Proyectos = new List<Proyecto>
                {
                    new Proyecto
                    {
                        Titulo = "Amazon",
                        Descripcion = "E-Commerce realizado en ASP.NET Core",
                        Link = "https://amazon.com",
                        ImagenURL = Url.Content("~/imagenes/amazon.png")
                    },
                    new Proyecto
                    {
                        Titulo = "New York Times",
                        Descripcion = "P�gina de noticias en React",
                        Link = "https://nytimes.com",
                        ImagenURL = Url.Content("~/imagenes/nyt.png")
                    },
                    new Proyecto
                    {
                        Titulo = "Reddit",
                        Descripcion = "Red social para compartir en comunidades",
                        Link = "https://reddit.com",
                        ImagenURL = Url.Content("~/imagenes/reddit.png")
                    },
                    new Proyecto
                    {
                        Titulo = "Steam",
                        Descripcion = "Tienda en l�nea para comprar videojuegos",
                        Link = "https://store.steampowered.com",
                        ImagenURL = Url.Content("~/imagenes/steam.png")
                    }
                }
                }
            };

            return View(p);
        }
    }
}


