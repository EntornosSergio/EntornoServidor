﻿namespace Practica1.Models
{
    public class ListaProyectos
    {
        public List<Proyecto> Proyectos { get; set; } = new List<Proyecto>();
    }
}
