﻿namespace Practica1.Models
{
    public class Persona
    {
        public string Nombre { get; set; }
        public int Edad { get; set; }
        public string Perfil { get; set; }
    }
}
