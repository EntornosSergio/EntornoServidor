﻿namespace Practica1.Models
{
    public class Portfolio
    {
     public Persona Persona { get; set; }
     public ListaProyectos Proyectos { get; set; }

    }
}
