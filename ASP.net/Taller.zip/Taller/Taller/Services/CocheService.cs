﻿using Taller.Interfaces;
using Taller.Models;

namespace Taller.Services
{
    public class CocheService : ICoche
    {
        public List<Coche> getCoches()
        {
            return new List<Coche>
            {
                new Coche
                {
                    Modelo = "Civic",
                    Matricula = "1234ABC",
                    Marca = "Honda",
                    Año = "2020"
                },
                new Coche
                {
                    Modelo = "Corolla",
                    Matricula = "5678XYZ",
                    Marca = "Toyota",
                    Año = "2019"
                }
            };
        }

    }
}
