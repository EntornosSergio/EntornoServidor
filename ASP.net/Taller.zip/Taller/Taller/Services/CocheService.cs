﻿using Taller.Interfaces;
using Taller.Models;

namespace Taller.Services
{
    public class CocheService : ICoche
    {
        public List<Coche> getCoches()
        {
            return new List<Coche>()
            {
                new Coche() {
                    Modelo = "Toyota",
                    Matricula = "8463YTR",
                    Año = "2009",
                    dueños = new Dueño() {
                        direccion = new Direccion() {
                              Calle = "Calle Ficticia",
                              Numero = 123,
                              CodigoPostal = 28001,
                              Provincia = "Madrid"
                        }
                    }
                }

            };
        }

    }
}
