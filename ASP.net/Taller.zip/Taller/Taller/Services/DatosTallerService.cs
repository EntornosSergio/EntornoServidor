﻿using Taller.Models;
using Taller.Interfaces;

namespace Taller.Services
{
    public class TallerService : ITaller
    {
        public Taller.Models.TallerInfo GetTaller()
        {
            return new Taller.Models.TallerInfo
            {
                Nombre = "Taller de SergisDaw",
                Telefono = "123456789",
                Mecanicos = new List<Mecanico>
                {
                    new Mecanico { 
                        Id = 1,
                        Nombre = "Albertostas",
                        FechaAlta = new DateTime(2011, 3, 12), 
                        Foto = "Fotoooooo" 
                    },
                     new Mecanico {
                        Id = 2,
                        Nombre = "Pinilla Palomo",
                        FechaAlta = new DateTime(2011, 3, 12),
                        Foto = "Fotoooooo paloma"
                    },
                      new Mecanico {
                        Id = 1,
                        Nombre = "AlexBrawl",
                        FechaAlta = new DateTime(2011, 3, 12),
                        Foto = "Cordelius"
                    }
                },

                Coches = new List<Coche>
                {
                    new Coche { 
                        Modelo = "Civic", 
                        Matricula = "1234ABC", 
                        Marca = "Honda", 
                        Año = "2020" }
                },
                Direccion = new Direccion
                {
                    Calle = "Calle Ficticia",
                    Numero = 123,
                    CodigoPostal = 28001,
                    Provincia = "Madrid"
                }
            };
        }
    }
}
