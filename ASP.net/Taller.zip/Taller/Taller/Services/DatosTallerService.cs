﻿using Taller.Models;
using Taller.Interfaces;
using static System.Runtime.InteropServices.JavaScript.JSType;
namespace Taller.Services
{
    public class DatosTallerService : ITaller
    {
        public Taller GetTaller()
        {
            return new Taller()
            {

                Nombre = "Taller Mecánico Juan",
                Telefono = "123456789",
                Mecanicos = new Mecanico
                {
                    FechaAlta = new DateTime(2011, 3, 12),
                    Foto = "Fotoooooo"
                },
                Coches = new Coche
                {
                    Modelo = "Civic",
                    Matricula = "1234ABC",
                    Marca = "Honda",
                    Año = "2020"
                },
                Direccion = new Direccion
                {
                    Calle = "Calle Ficticia",
                    Numero = 123,
                    CodigoPostal = 28001,
                    Provincia = "Madrid"
                }

            }
        };
    }
}
