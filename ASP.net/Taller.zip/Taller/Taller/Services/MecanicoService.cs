﻿using Taller.Interfaces;
using Taller.Models;

namespace Taller.Services
{
    public class MecanicoService : IMecanico
    {
        public List<Mecanico> getMecanicos()
        {
            return new List<Mecanico>()
            {
                new Mecanico()
                {
                    FechaAlta= new DateTime(2020, 5, 15),
                    Foto="Foto"
                }
            };
        }
    }
}
