﻿using Taller.Interfaces;
using Taller.Models;

namespace Taller.Services
{
    public class MecanicoService : IMecanico
    {
        public List<Mecanico> getMecanicos()
        {
            return new List<Mecanico>
        {
             new Mecanico {
                        Id = 1,
                        Nombre = "Albertostas",
                        FechaAlta = new DateTime(2011, 3, 12),
                        Foto = "Fotoooooo"
                    },
                 new Mecanico {
                        Id = 2,
                        Nombre = "Pinilla Palomo",
                        FechaAlta = new DateTime(2011, 3, 12),
                        Foto = "Fotoooooo paloma"
                    },
                     new Mecanico {
                        Id = 1,
                        Nombre = "AlexBrawl",
                        FechaAlta = new DateTime(2011, 3, 12),
                        Foto = "Cordelius"
                    }
            };
        }
    }

}
