﻿namespace Taller.Models
{
    public class Taller
    {
        public string Nombre { get; set; }  
        public string Telefono { get; set; }
        public Mecanico mecanicos { get; set; }
        public Coche coches { get; set; }
        public Direccion direccion { get; set; }

    }
}
