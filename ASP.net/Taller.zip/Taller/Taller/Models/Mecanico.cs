﻿namespace Taller.Models
{
    public class Mecanico : Persona
    {
        public DateTime FechaAlta { get; set; }
        public string Foto { get; set; }

    }
}
