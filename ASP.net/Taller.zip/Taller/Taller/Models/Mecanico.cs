﻿namespace Taller.Models
{
    public class Mecanico : Persona
    {
        public int Id { get; set; } 
        public string? Nombre { get; set; }
        public DateTime FechaAlta { get; set; }
        public string Foto { get; set; }

    }
}
