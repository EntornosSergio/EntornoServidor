﻿namespace Taller.Models
{
    public class TallerInfo
    {
        public string Nombre { get; set; }
        public string Telefono { get; set; }
        public List<Mecanico> Mecanicos { get; set; }
        public List<Coche> Coches { get; set; }
        public Direccion Direccion { get; set; }
    }
}
