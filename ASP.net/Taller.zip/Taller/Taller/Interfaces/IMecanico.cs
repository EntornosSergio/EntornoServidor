﻿using Taller.Models;
namespace Taller.Interfaces
{
    public interface IMecanico
    {
        public List<Mecanico> getMecanicos();
    }
}
