﻿using Taller.Models;
namespace Taller.Interfaces
{
    public interface ITaller
    {
        public Taller GetTaller();
    }
}
