﻿using Taller.Models;
namespace Taller.Interfaces
{
    public interface ICoche
    {
        public List<Coche> getCoches();
    }
}
