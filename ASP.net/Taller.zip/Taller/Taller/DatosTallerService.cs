﻿internal class DatosTallerService
{
}