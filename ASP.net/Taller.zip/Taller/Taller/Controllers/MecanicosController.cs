﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Taller.Interfaces;
using Taller.Models;

namespace Taller.Controllers
{
    public class MecanicosController : Controller
    {
        private readonly ILogger<MecanicosController> _logger;
        private readonly IMecanico _mecanicoService;

        public MecanicosController(ILogger<MecanicosController> logger, IMecanico mecanicoService)
        {
            _logger = logger;
            _mecanicoService = mecanicoService;
        }
    
        public IActionResult Index()
        {
            var mecanicos = _mecanicoService.getMecanicos(); 
            return View(mecanicos);
        }


    }
}
