using Microsoft.AspNetCore.Mvc;
using Taller.Interfaces;

namespace Taller.Controllers
{
    public class HomeController : Controller
    {
        private readonly ITaller _data;

        public HomeController(ITaller data)
        {
            _data = data;
        }

        public IActionResult Index()
        {
            var taller = _data.GetTaller();
            return View(taller);
        }
    }
}

