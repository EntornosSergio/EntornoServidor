﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Taller.Interfaces;

namespace Taller.Controllers
{
    public class CochesController : Controller
    {
        private readonly ILogger<CochesController> _logger;
        private readonly ICoche _cochesService;

        public CochesController(ILogger<CochesController> logger, ICoche cocheService)
        {
            _logger = logger;
            _cochesService = cocheService;
        }

        public ActionResult Index()
        {
            return View(_cochesService.getCoches());
        }
    }
}

