﻿namespace Ejemplo_modelos.Models
{
    public class Alumno
    {
        public String Nombre { get;set; }
        public String DNI {  get;set; }
        public double Nota {  get;set; }    


    }
}
