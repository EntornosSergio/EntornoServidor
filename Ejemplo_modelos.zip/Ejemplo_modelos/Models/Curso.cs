﻿namespace Ejemplo_modelos.Models
{
    public class Curso
    {
        public List<Alumno>? miLista { get; set; } 
        public string? Nombre {  get; set; }
         
       




    }
}
