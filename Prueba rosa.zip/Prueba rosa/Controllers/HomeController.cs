using Microsoft.AspNetCore.Mvc;
using Prueba_rosa.Models;
using System.Diagnostics;
using System.Globalization;

namespace Prueba_rosa.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult TeSaludo()
        {
            return View();
        }
        public IActionResult MeDespido()
        {
            return View();
        }
        public IActionResult TeSaludoTi()
        {
            string nombre = "Samuelin";
            int edad = -2;
            string mensaje = "";
            if (edad < 50)
                mensaje = "que bb";
            else
                mensaje = "q mayor";

            ViewData["name"] = nombre;
            ViewData["age"] = edad;
            ViewData["msg"] = mensaje;
            
            return View();

        }

    }
}
